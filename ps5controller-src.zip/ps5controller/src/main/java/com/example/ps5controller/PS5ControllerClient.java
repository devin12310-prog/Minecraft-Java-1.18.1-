package com.example.ps5controller;

import com.example.ps5controller.mixin.KeyBindingAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;

/**
 * PS5 DualSense support. When the controller is paired over Bluetooth the OS exposes it
 * as a normal gamepad, and GLFW (already bundled with Minecraft) reads it.
 *
 * Layout (GLFW gamepad names -> PS5 buttons):
 *  Left stick  move          Right stick  look
 *  Cross       jump          Circle       sneak (hold) / close screens
 *  Square      swap hands    Triangle     inventory
 *  L1 / R1     hotbar prev / next
 *  L2          use / place   R2           attack / break
 *  L3          toggle sprint
 *  D-pad up    drop item     D-pad down   change perspective
 *  Create      player list   Options      pause menu
 */
public class PS5ControllerClient implements ClientModInitializer {

    public static class Pad {
        public volatile boolean active;
        public volatile float forward, sideways;
        public volatile boolean jump, sneak;
    }

    public static final Pad PAD = new Pad();

    private static final float DEADZONE = 0.15f;
    private static final float LOOK_SPEED = 30f;   // raise for faster camera
    private static final float TRIGGER = 0.3f;

    // GLFW gamepad indices
    private static final int CROSS = 0, CIRCLE = 1, SQUARE = 2, TRIANGLE = 3, L1 = 4, R1 = 5,
            CREATE = 6, OPTIONS = 7, L3 = 9, DPAD_UP = 11, DPAD_DOWN = 13;

    private static GLFWGamepadState state;
    private static int activeJid = -1;
    private static boolean wasActive;
    private static final boolean[] prev = new boolean[15];
    private static boolean prevL2, prevR2, sprintOn, sprintApplied;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.START_CLIENT_TICK.register(PS5ControllerClient::tick);
    }

    private static boolean poll() {
        if (state == null) state = GLFWGamepadState.malloc();
        for (int jid = GLFW.GLFW_JOYSTICK_1; jid <= GLFW.GLFW_JOYSTICK_LAST; jid++) {
            if (GLFW.glfwJoystickIsGamepad(jid) && GLFW.glfwGetGamepadState(jid, state)) { activeJid = jid; return true; }
        }
        return false;
    }

    private static float dz(float v) {
        float a = Math.abs(v);
        if (a < DEADZONE) return 0f;
        float scaled = (a - DEADZONE) / (1f - DEADZONE);
        return Math.copySign(scaled, v);
    }

    private static boolean btn(int i) { return state.buttons(i) == GLFW.GLFW_PRESS; }

    private static void key(KeyBinding kb, boolean down, boolean was) {
        if (down && !was) {
            KeyBindingAccessor acc = (KeyBindingAccessor) kb;
            acc.ps5$setTimesPressed(acc.ps5$getTimesPressed() + 1);
        }
        if (down != was) kb.setPressed(down);
    }

    private static void tick(MinecraftClient mc) {
        if (!poll()) {
            PAD.active = false;
            if (wasActive) {
                wasActive = false;
                SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                        new LiteralText("Controller disconnected"), null);
            }
            return;
        }
        PAD.active = true;
        if (!wasActive) {
            wasActive = true;
            String name = GLFW.glfwGetGamepadName(activeJid);
            SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                    new LiteralText("Controller connected"),
                    new LiteralText(name != null ? name : "Gamepad"));
        }

        boolean[] now = new boolean[15];
        for (int i = 0; i < 15; i++) now[i] = btn(i);
        boolean l2 = state.axes(4) > TRIGGER;
        boolean r2 = state.axes(5) > TRIGGER;

        float lx = dz(state.axes(0)), ly = dz(state.axes(1));
        float rx = dz(state.axes(2)), ry = dz(state.axes(3));

        boolean inGame = mc.player != null && mc.currentScreen == null;

        if (!inGame) {
            PAD.forward = PAD.sideways = 0f;
            PAD.jump = PAD.sneak = false;
            if (mc.currentScreen != null && ((now[CIRCLE] && !prev[CIRCLE]) || (now[TRIANGLE] && !prev[TRIANGLE]))) {
                mc.setScreen(null); // close inventory/chest/etc.
            }
        } else {
            PAD.forward = -ly;
            PAD.sideways = -lx;
            PAD.jump = now[CROSS];
            PAD.sneak = now[CIRCLE];

            // camera
            float yaw = Math.copySign(rx * rx, rx) * LOOK_SPEED;
            float pitch = Math.copySign(ry * ry, ry) * LOOK_SPEED;
            if (yaw != 0f || pitch != 0f) mc.player.changeLookDirection(yaw, pitch);

            // actions
            key(mc.options.keyAttack, r2, prevR2);
            key(mc.options.keyUse, l2, prevL2);
            key(mc.options.keySwapHands, now[SQUARE], prev[SQUARE]);
            key(mc.options.keyInventory, now[TRIANGLE], prev[TRIANGLE]);
            key(mc.options.keyDrop, now[DPAD_UP], prev[DPAD_UP]);
            key(mc.options.keyTogglePerspective, now[DPAD_DOWN], prev[DPAD_DOWN]);
            key(mc.options.keyPlayerList, now[CREATE], prev[CREATE]);

            // hotbar
            if (now[R1] && !prev[R1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 1) % 9;
            if (now[L1] && !prev[L1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 8) % 9;

            // sprint toggle (L3), only while pushing forward
            if (now[L3] && !prev[L3]) sprintOn = !sprintOn;
            if (PAD.forward <= 0.1f) sprintOn = false;
            if (sprintOn || sprintApplied) {
                mc.options.keySprint.setPressed(sprintOn);
                sprintApplied = sprintOn;
            }

            // pause
            if (now[OPTIONS] && !prev[OPTIONS]) mc.openPauseMenu(false);
        }

        System.arraycopy(now, 0, prev, 0, 15);
        prevL2 = l2;
        prevR2 = r2;
    }
}

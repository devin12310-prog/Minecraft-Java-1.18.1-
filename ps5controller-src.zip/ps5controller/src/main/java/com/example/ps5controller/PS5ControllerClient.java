package com.example.ps5controller;

import com.example.ps5controller.mixin.KeyBindingAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;
import org.lwjgl.system.MemoryStack;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.Arrays;

/**
 * PS5 DualSense support over Bluetooth (read through GLFW, which Minecraft already bundles).
 * Controller input only works in-game: it is ignored whenever any menu/screen is open.
 *
 *  Left stick move        Right stick look
 *  Cross jump             Circle sneak (hold)
 *  Square swap hands      Triangle inventory
 *  L1 / R1 hotbar         L2 use       R2 attack
 *  L3 toggle sprint       D-pad up drop     D-pad down perspective
 *  Create player list     Options pause menu
 */
public class PS5ControllerClient implements ClientModInitializer {

    public static class Pad {
        public volatile boolean active;
        public volatile float forward, sideways;
        public volatile boolean jump, sneak;
    }

    public static final Pad PAD = new Pad();

    private static final float DEADZONE = 0.15f;
    private static final float LOOK_SPEED = 600f; // look units per second at full stick
    private static final float TRIGGER = 0.3f;

    // Index layout shared by the GLFW gamepad API and my raw fallback
    private static final int CROSS = 0, CIRCLE = 1, SQUARE = 2, TRIANGLE = 3, L1 = 4, R1 = 5,
            CREATE = 6, OPTIONS = 7, L3 = 9, DPAD_UP = 11, DPAD_DOWN = 13;

    // SDL mapping for the DualSense on Windows (Bluetooth or USB)
    private static final String DUALSENSE_MAPPING =
            "030000004c050000e60c000000000000,PS5 Controller,a:b1,b:b2,x:b0,y:b3,back:b8,guide:b13,"
            + "start:b9,leftstick:b10,rightstick:b11,leftshoulder:b4,rightshoulder:b5,"
            + "dpup:h0.1,dpright:h0.2,dpdown:h0.4,dpleft:h0.8,lefttrigger:a3,righttrigger:a4,"
            + "leftx:a0,lefty:a1,rightx:a2,righty:a5,platform:Windows,\n";

    private static GLFWGamepadState state;
    private static boolean mappingsLoaded;
    private static final float[] ax = new float[6];
    private static final boolean[] bt = new boolean[15];
    private static int activeJid = -1;
    private static boolean wasActive, warnedUnsupported;
    private static String padName = "Gamepad";
    private static String pendingToast; // connected / disconnected / unsupported
    private static final boolean[] prev = new boolean[15];
    private static boolean prevL2, prevR2, sprintOn, sprintApplied;
    private static long lastFrame;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.START_CLIENT_TICK.register(PS5ControllerClient::tick);
        WorldRenderEvents.START.register(ctx -> frameLook(MinecraftClient.getInstance()));
        HudRenderCallback.EVENT.register(PS5ControllerClient::hud);
    }

    private static boolean pressed(ByteBuffer b, int i) { return b.get(i) != 0; }

    /** Fills ax[] and bt[]. Returns true if a usable controller was found. */
    private static boolean readPad() {
        if (state == null) state = GLFWGamepadState.malloc();
        if (!mappingsLoaded) {
            mappingsLoaded = true;
            try (MemoryStack stack = MemoryStack.stackPush()) {
                GLFW.glfwUpdateGamepadMappings(stack.UTF8(DUALSENSE_MAPPING));
            } catch (Throwable ignored) { }
        }

        // 1) Normal gamepad (uses GLFW mappings)
        for (int jid = GLFW.GLFW_JOYSTICK_1; jid <= GLFW.GLFW_JOYSTICK_LAST; jid++) {
            if (GLFW.glfwJoystickPresent(jid) && GLFW.glfwJoystickIsGamepad(jid)
                    && GLFW.glfwGetGamepadState(jid, state)) {
                for (int i = 0; i < 6; i++) ax[i] = state.axes(i);
                for (int i = 0; i < 15; i++) bt[i] = state.buttons(i) == GLFW.GLFW_PRESS;
                activeJid = jid;
                return true;
            }
        }

        // 2) Fallback: read a DualSense directly if GLFW has no mapping for it
        for (int jid = GLFW.GLFW_JOYSTICK_1; jid <= GLFW.GLFW_JOYSTICK_LAST; jid++) {
            if (!GLFW.glfwJoystickPresent(jid)) continue;
            String nm = GLFW.glfwGetJoystickName(jid);
            if (nm == null) continue;
            String l = nm.toLowerCase();
            if (!(l.contains("wireless controller") || l.contains("dualsense") || l.contains("ps5"))) continue;
            FloatBuffer a = GLFW.glfwGetJoystickAxes(jid);
            ByteBuffer b = GLFW.glfwGetJoystickButtons(jid);
            ByteBuffer h = GLFW.glfwGetJoystickHats(jid);
            if (a == null || b == null || a.remaining() < 6 || b.remaining() < 12) continue;

            ax[0] = a.get(0); ax[1] = a.get(1); ax[2] = a.get(2);
            ax[3] = a.get(5); // right stick Y
            ax[4] = a.get(3); // L2
            ax[5] = a.get(4); // R2
            Arrays.fill(bt, false);
            bt[CROSS] = pressed(b, 1);
            bt[CIRCLE] = pressed(b, 2);
            bt[SQUARE] = pressed(b, 0);
            bt[TRIANGLE] = pressed(b, 3);
            bt[L1] = pressed(b, 4);
            bt[R1] = pressed(b, 5);
            bt[CREATE] = pressed(b, 8);
            bt[OPTIONS] = pressed(b, 9);
            bt[L3] = pressed(b, 10);
            bt[10] = pressed(b, 11);
            if (h != null && h.remaining() > 0) {
                int hv = h.get(0);
                bt[DPAD_UP] = (hv & GLFW.GLFW_HAT_UP) != 0;
                bt[12] = (hv & GLFW.GLFW_HAT_RIGHT) != 0;
                bt[DPAD_DOWN] = (hv & GLFW.GLFW_HAT_DOWN) != 0;
                bt[14] = (hv & GLFW.GLFW_HAT_LEFT) != 0;
            }
            activeJid = jid;
            return true;
        }
        return false;
    }

    private static String currentName() {
        String n = GLFW.glfwGetGamepadName(activeJid);
        if (n == null) n = GLFW.glfwGetJoystickName(activeJid);
        return n != null ? n : "Gamepad";
    }

    private static float dz(float v) {
        float a = Math.abs(v);
        if (a < DEADZONE) return 0f;
        return Math.copySign((a - DEADZONE) / (1f - DEADZONE), v);
    }

    private static void key(KeyBinding kb, boolean down, boolean was) {
        if (down && !was) {
            KeyBindingAccessor acc = (KeyBindingAccessor) kb;
            acc.ps5$setTimesPressed(acc.ps5$getTimesPressed() + 1);
        }
        if (down != was) kb.setPressed(down);
    }

    /** Camera runs every frame (not every 20 ticks/sec) so it is smooth. */
    private static void frameLook(MinecraftClient mc) {
        long n = System.nanoTime();
        float dt = lastFrame == 0 ? 0f : (n - lastFrame) / 1_000_000_000f;
        lastFrame = n;
        dt = Math.min(dt, 0.1f);
        if (mc.player == null || mc.currentScreen != null || !wasActive) return;
        if (!readPad()) return;
        float rx = dz(ax[2]), ry = dz(ax[3]);
        float yaw = Math.copySign(rx * rx, rx) * LOOK_SPEED * dt;
        float pitch = Math.copySign(ry * ry, ry) * LOOK_SPEED * dt;
        if (yaw != 0f || pitch != 0f) mc.player.changeLookDirection(yaw, pitch);
    }

    /** Small status line in the top-right corner, only while playing (never in menus). */
    private static void hud(MatrixStack matrices, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden || mc.options.debugEnabled) return;
        String text = wasActive ? "Controller: Connected" : "Controller: Not connected";
        int color = wasActive ? 0x55FF55 : 0xFF5555;
        int w = mc.textRenderer.getWidth(text);
        mc.textRenderer.drawWithShadow(matrices, text, mc.getWindow().getScaledWidth() - w - 4, 4, color);
    }

    private static void tick(MinecraftClient mc) {
        boolean found = readPad();

        if (found && !wasActive) {
            wasActive = true;
            warnedUnsupported = false;
            padName = currentName();
            pendingToast = "connected";
        } else if (!found && wasActive) {
            wasActive = false;
            pendingToast = "disconnected";
        } else if (!found && !warnedUnsupported) {
            // Something is plugged in/paired but I can't use it: tell the player what GLFW sees.
            for (int jid = GLFW.GLFW_JOYSTICK_1; jid <= GLFW.GLFW_JOYSTICK_LAST; jid++) {
                if (GLFW.glfwJoystickPresent(jid)) {
                    String nm = GLFW.glfwGetJoystickName(jid);
                    padName = nm != null ? nm : "Unknown device";
                    warnedUnsupported = true;
                    pendingToast = "unsupported";
                    break;
                }
            }
        }

        // Wait until the loading screen is gone so the popup text renders correctly.
        if (pendingToast != null && mc.getOverlay() == null) {
            switch (pendingToast) {
                case "connected":
                    SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                            new LiteralText("Controller connected"), new LiteralText(padName));
                    break;
                case "unsupported":
                    SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                            new LiteralText("Controller not supported"), new LiteralText(padName));
                    break;
                default:
                    SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                            new LiteralText("Controller disconnected"), null);
            }
            pendingToast = null;
        }

        if (!found) { PAD.active = false; return; }
        PAD.active = true;

        boolean[] now = bt.clone();
        boolean l2 = ax[4] > TRIGGER;
        boolean r2 = ax[5] > TRIGGER;
        float lx = dz(ax[0]), ly = dz(ax[1]);

        boolean inGame = mc.player != null && mc.currentScreen == null;

        if (!inGame) {
            PAD.forward = PAD.sideways = 0f;
            PAD.jump = PAD.sneak = false;
            key(mc.options.keyAttack, false, prevR2);
            key(mc.options.keyUse, false, prevL2);
            if (sprintApplied) { mc.options.keySprint.setPressed(false); sprintApplied = false; }
            sprintOn = false;
            l2 = false;
            r2 = false;
        } else {
            PAD.forward = -ly;
            PAD.sideways = -lx;
            PAD.jump = now[CROSS];
            PAD.sneak = now[CIRCLE];

            key(mc.options.keyAttack, r2, prevR2);
            key(mc.options.keyUse, l2, prevL2);
            key(mc.options.keySwapHands, now[SQUARE], prev[SQUARE]);
            key(mc.options.keyInventory, now[TRIANGLE], prev[TRIANGLE]);
            key(mc.options.keyDrop, now[DPAD_UP], prev[DPAD_UP]);
            key(mc.options.keyTogglePerspective, now[DPAD_DOWN], prev[DPAD_DOWN]);
            key(mc.options.keyPlayerList, now[CREATE], prev[CREATE]);

            if (now[R1] && !prev[R1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 1) % 9;
            if (now[L1] && !prev[L1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 8) % 9;

            if (now[L3] && !prev[L3]) sprintOn = !sprintOn;
            if (PAD.forward <= 0.1f) sprintOn = false;
            if (sprintOn || sprintApplied) {
                mc.options.keySprint.setPressed(sprintOn);
                sprintApplied = sprintOn;
            }

            if (now[OPTIONS] && !prev[OPTIONS]) mc.openPauseMenu(false);
        }

        System.arraycopy(now, 0, prev, 0, 15);
        prevL2 = l2;
        prevR2 = r2;
    }
}

package com.example.ps5controller;

import com.example.ps5controller.mixin.KeyBindingAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;

/**
 * PS5 DualSense support over Bluetooth (read through GLFW, which Minecraft already bundles).
 * Controller input only works in-game: it is ignored whenever any menu/screen is open.
 *
 *  Left stick move        Right stick look
 *  Cross jump             Circle sneak (hold)
 *  Square swap hands      Triangle inventory
 *  L1 / R1 hotbar         L2 use       R2 attack
 *  L3 toggle sprint       D-pad up drop     D-pad down perspective
 *  Create player list     Options pause menu
 */
public class PS5ControllerClient implements ClientModInitializer {

    public static class Pad {
        public volatile boolean active;
        public volatile float forward, sideways;
        public volatile boolean jump, sneak;
    }

    public static final Pad PAD = new Pad();

    private static final float DEADZONE = 0.15f;
    private static final float LOOK_SPEED = 30f;
    private static final float TRIGGER = 0.3f;

    private static final int CROSS = 0, CIRCLE = 1, SQUARE = 2, TRIANGLE = 3, L1 = 4, R1 = 5,
            CREATE = 6, OPTIONS = 7, L3 = 9, DPAD_UP = 11, DPAD_DOWN = 13;

    private static GLFWGamepadState state;
    private static int activeJid = -1;
    private static boolean wasActive;
    private static String padName = "Gamepad";
    private static String pendingToast; // "connected" / "disconnected"
    private static final boolean[] prev = new boolean[15];
    private static boolean prevL2, prevR2, sprintOn, sprintApplied;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.START_CLIENT_TICK.register(PS5ControllerClient::tick);
        HudRenderCallback.EVENT.register(PS5ControllerClient::hud);
    }

    private static boolean poll() {
        if (state == null) state = GLFWGamepadState.malloc();
        for (int jid = GLFW.GLFW_JOYSTICK_1; jid <= GLFW.GLFW_JOYSTICK_LAST; jid++) {
            if (GLFW.glfwJoystickIsGamepad(jid) && GLFW.glfwGetGamepadState(jid, state)) {
                activeJid = jid;
                return true;
            }
        }
        return false;
    }

    private static float dz(float v) {
        float a = Math.abs(v);
        if (a < DEADZONE) return 0f;
        return Math.copySign((a - DEADZONE) / (1f - DEADZONE), v);
    }

    private static boolean btn(int i) { return state.buttons(i) == GLFW.GLFW_PRESS; }

    private static void key(KeyBinding kb, boolean down, boolean was) {
        if (down && !was) {
            KeyBindingAccessor acc = (KeyBindingAccessor) kb;
            acc.ps5$setTimesPressed(acc.ps5$getTimesPressed() + 1);
        }
        if (down != was) kb.setPressed(down);
    }

    /** Small status line in the top-right corner, only while playing (never in menus). */
    private static void hud(MatrixStack matrices, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden || mc.options.debugEnabled) return;
        String text = wasActive ? "Controller: Connected" : "Controller: Not connected";
        int color = wasActive ? 0x55FF55 : 0xFF5555;
        int w = mc.textRenderer.getWidth(text);
        mc.textRenderer.drawWithShadow(matrices, text, mc.getWindow().getScaledWidth() - w - 4, 4, color);
    }

    private static void tick(MinecraftClient mc) {
        boolean found = poll();

        if (found && !wasActive) {
            wasActive = true;
            String n = GLFW.glfwGetGamepadName(activeJid);
            padName = n != null ? n : "Gamepad";
            pendingToast = "connected";
        } else if (!found && wasActive) {
            wasActive = false;
            pendingToast = "disconnected";
        }

        // Wait until the loading screen is gone so the popup text renders correctly.
        if (pendingToast != null && mc.getOverlay() == null) {
            if (pendingToast.equals("connected")) {
                SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                        new LiteralText("Controller connected"), new LiteralText(padName));
            } else {
                SystemToast.add(mc.getToastManager(), SystemToast.Type.TUTORIAL_HINT,
                        new LiteralText("Controller disconnected"), null);
            }
            pendingToast = null;
        }

        if (!found) { PAD.active = false; return; }
        PAD.active = true;

        boolean[] now = new boolean[15];
        for (int i = 0; i < 15; i++) now[i] = btn(i);
        boolean l2 = state.axes(4) > TRIGGER;
        boolean r2 = state.axes(5) > TRIGGER;

        float lx = dz(state.axes(0)), ly = dz(state.axes(1));
        float rx = dz(state.axes(2)), ry = dz(state.axes(3));

        boolean inGame = mc.player != null && mc.currentScreen == null;

        if (!inGame) {
            // Menus / loading: controller does nothing. Release anything we were holding.
            PAD.forward = PAD.sideways = 0f;
            PAD.jump = PAD.sneak = false;
            key(mc.options.keyAttack, false, prevR2);
            key(mc.options.keyUse, false, prevL2);
            if (sprintApplied) { mc.options.keySprint.setPressed(false); sprintApplied = false; }
            sprintOn = false;
            l2 = false;
            r2 = false;
        } else {
            PAD.forward = -ly;
            PAD.sideways = -lx;
            PAD.jump = now[CROSS];
            PAD.sneak = now[CIRCLE];

            float yaw = Math.copySign(rx * rx, rx) * LOOK_SPEED;
            float pitch = Math.copySign(ry * ry, ry) * LOOK_SPEED;
            if (yaw != 0f || pitch != 0f) mc.player.changeLookDirection(yaw, pitch);

            key(mc.options.keyAttack, r2, prevR2);
            key(mc.options.keyUse, l2, prevL2);
            key(mc.options.keySwapHands, now[SQUARE], prev[SQUARE]);
            key(mc.options.keyInventory, now[TRIANGLE], prev[TRIANGLE]);
            key(mc.options.keyDrop, now[DPAD_UP], prev[DPAD_UP]);
            key(mc.options.keyTogglePerspective, now[DPAD_DOWN], prev[DPAD_DOWN]);
            key(mc.options.keyPlayerList, now[CREATE], prev[CREATE]);

            if (now[R1] && !prev[R1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 1) % 9;
            if (now[L1] && !prev[L1]) mc.player.getInventory().selectedSlot = (mc.player.getInventory().selectedSlot + 8) % 9;

            if (now[L3] && !prev[L3]) sprintOn = !sprintOn;
            if (PAD.forward <= 0.1f) sprintOn = false;
            if (sprintOn || sprintApplied) {
                mc.options.keySprint.setPressed(sprintOn);
                sprintApplied = sprintOn;
            }

            if (now[OPTIONS] && !prev[OPTIONS]) mc.openPauseMenu(false);
        }

        System.arraycopy(now, 0, prev, 0, 15);
        prevL2 = l2;
        prevR2 = r2;
    }
}
